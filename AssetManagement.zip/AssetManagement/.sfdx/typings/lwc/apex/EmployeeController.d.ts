declare module "@salesforce/apex/EmployeeController.getEmployess" {
  export default function getEmployess(): Promise<any>;
}
declare module "@salesforce/apex/EmployeeController.getAvailableDesks" {
  export default function getAvailableDesks(param: {building: any, floor: any, wing: any}): Promise<any>;
}
